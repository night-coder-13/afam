<template>
    <Header />
    <Customer />
    <GlobalMarket />
    <Feature />
    <Product />
    <Coop />
    <Blog />
    <Contact />
    <Footer />
</template>

<script setup>
import Header from './home-sections/header.vue'
import Customer from './home-sections/customer.vue'
import GlobalMarket from './home-sections/global-market.vue'
import Feature from './home-sections/feature.vue'
import Product from './home-sections/product2.vue'
import Coop from './home-sections/coop.vue'
import Blog from './home-sections/blog.vue'
import Contact from './home-sections/contact.vue'
import Footer from './home-sections/footer.vue'
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
