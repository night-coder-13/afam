<template>
    <div class="flex w-11/12 m-auto my-20 ">
        <div class="w-3/12 h-24 flex grid grid-cols-1 justify-items-center items-center px-4 py-8">
            <p class="text-4xl"><span class="font-bold">+</span> 125</p>
            <p class="mt-3 font-bold uppercase">Product</p>
        </div>
        <div class="w-3/12 h-24 flex grid grid-cols-1 justify-items-center items-center px-4 py-8">
            <p class="text-4xl"><span class="font-bold">+</span> 5</p>
            <p class="mt-3 font-bold uppercase">years of experience</p>
        </div>
        <div class="w-3/12 h-24 grid grid-cols-1 justify-items-center items-center px-4 py-8">
            <p class="text-4xl"><span class="font-bold">+</span> 85</p>
            <p class="mt-3 font-bold uppercase">Work samples</p>
        </div>
        <div class="w-3/12 h-24 ">
            <div class="w-full bg-blue-900 px-4 py-8 rounded-lg text-gray-100 font-bold grid grid-cols-1 justify-items-center items-center ">
                <div class="flex mr-4">
                    <img src="../../assets/img/img(10).webp" class="w-10 h-10 grayscale rounded-full -mr-4" alt="">
                    <img src="../../assets/img/img(10).webp" class="w-10 h-10 grayscale rounded-full -mr-4" alt="">
                    <img src="../../assets/img/img(10).webp" class="w-10 h-10 grayscale rounded-full -mr-4" alt="">
                    <img src="../../assets/img/img(10).webp" class="w-10 h-10 grayscale rounded-full -mr-4" alt="">
                    <img src="../../assets/img/img(10).webp" class="w-10 h-10 grayscale rounded-full -mr-4" alt="">
                </div>
                <p class="mt-3 font-bold uppercase">Satisfaction of our customers</p>
            </div>
            
        </div>
    </div>
</template>

<script>

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.grayscale{
-webkit-filter: grayscale(1);
        filter: grayscale(1);
}
.grayscale:hover{
-webkit-filter: grayscale(0);
        filter: grayscale(0);
        transition: .5s;
}
</style>
