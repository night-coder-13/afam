<template>
    <div class="py-24 px-16 my-10 w-full section-coop">
        <div class="flex items-center relative">
            <img src="../../assets/quotes-right.svg" class="absolute -top-36 w-32" alt="">
            <div class="w-7/12 text-white">
                <h2 class="text-3xl font-bold Acme">Cope stone</h2>
                <p class="text-base ml-3 mt-2">Another name is Coop stone, block stone. Cope stone does not have a specific type in terms of gender, and all types of stones that are extracted from the mine are initially in the form of cope.
                    Therefore, coupe stones can be made of granite, marble and travertine. But the classification of all kinds of Kop stones is done based on its size and quality. In this category, there are a total of three types of Kop stones:

                    One coupe
                    Kop Tek Kop stone is of high quality because it has no cracks or scratches and its color harmony is high. The dimensions of the single cup stone are large and its shape is cut in a hexagonal shape. The weight of a single cup stone is 25 to 27 tons. Due to its dimensions and high weight, each single piece of rock is transported on a trailer.

                    Two coupes
                    The dimensions of the double cup stone are smaller than the single cup stone. In fact, two stones and two cups are equal to one single cup. Du Kop stones are usually in the shape of a rectangular cube, but they may not have a special shape. Two stones can be loaded on a trailer.

                    Three coupes
                    The dimensions of three cup stones are smaller than two cup stones. In fact, all three three-cup stones are equal to one single-cup stone. Therefore, in transportation, three pieces of stone, three cups, are transported on one trailer.</p>
                    
            </div>
            <div class="w-5/12">
                <img src="../../assets/img/stone.jpg" class="w-11/12 rounded-xl shadow m-auto" alt="">
            </div>
        </div>
    </div>
</template>

<script>

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.section-coop{
    background: linear-gradient(70deg, #070707a2 , rgba(0, 0, 0, 0) ) , url(../../assets/img/male-worker-with-bulldozer-sand-quarry.jpg) ;
    background-size: cover;
    background-position: center;
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
}
</style>
